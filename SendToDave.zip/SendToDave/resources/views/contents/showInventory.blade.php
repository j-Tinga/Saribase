@extends('layout.layout')

@section('products')
    bg-gray-500
@endsection

@section('content')


<div class="flex justify-center">
    <div class="w-9/12 flex flex-col">
            <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
              <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                
                  <div class="mb-6 flex justify-between">
                    <div class="flex items-center  mr-4">
                        <h1 class="text-2xl font-semibold uppercase">Branch Inventory</h1>
                    </div>
                  </div>
                

                <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-md">
                <div class="px-6 py-4 whitespace-nowrap bg-white text-gray-900 text-md font-semibold flex items-center"> 
                      
                        <button onclick="window.location='{{ route('admin') }}'"  class="mr-6 bg-blue-500 text-white px-4 py-3 w-40 rounded-sm text-sm hover:bg-blue-300 ">Back to Branches Tab</button>
                       
                </div>

                  <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                          <tr>
                             <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Item ID
                             </th>
                             <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Item Name
                             </th>
                             <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Price
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Selling Price
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Stock
                            </th>
             
                          </tr>   
                    </thead> 
                    <tbody class="bg-white divide-y divide-gray-200"> 
                 
                    @foreach($showInv as $key => $item)
                        
                        <tr>
                        <td class="px-6 py-4 whitespace-nowrap">{{$item->itemID}}</td>
                        <td class="px-6 py-4 whitespace-nowrap">{{$item->itemName}}</td>
                        <td class="px-6 py-4 whitespace-nowrap">{{$item->price}}</td>
                        <td class="px-6 py-4 whitespace-nowrap">{{$item->sellingPrice}}</td>
                        <td class="px-6 py-4 whitespace-nowrap">{{$item->itemQuantity}}</td>
                        </tr>
                        
                    @endforeach
                   
                    </tbody>
                 </table>
                
            </div>
            </div>  
        </div>
    </div>
</div>
<!--Live search ajax  -->
<script type="text/javascript">

    $('#search').on('keyup',function(){
        $value=$(this).val();
            $.ajax({
            type : 'get',
            url : '{{URL::to('searchProduct')}}',
            data:{'search':$value},
            success:function(data){
            $('tbody').html(data);
            }
        });
    })

    $.ajaxSetup({ headers: { 'csrftoken' : '{{ csrf_token() }}' } });

    function toggleModal(modalID){
    document.getElementById(modalID).classList.toggle("hidden");
    document.getElementById("backdrop").classList.toggle("hidden");
    document.getElementById(modalID).classList.toggle("flex");
    document.getElementById("backdrop").classList.toggle("flex");
    
  }
</script>

@endsection

