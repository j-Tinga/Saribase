<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ViewController;
use App\Http\Controllers\RequestController;
use App\Http\Controllers\RequestListController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\DisplayController;
use App\Http\Controllers\BranchInventory;
use App\Http\Controllers\ProductsPage; // newly added
// use Symfony\Component\Console\Input\Input;
use App\Http\Controllers\Session;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//View for pages
Route::get('/', [ViewController:: class, 'home']);
Route::get('/home', [ViewController:: class, 'home']);
Route::get('/login', [ViewController:: class, 'loginform']);
Route::get('/request', [ViewController:: class, 'requestform']);
Route::get('/request_list', [ViewController:: class, 'request_list']);
Route::get('/branch_inventory', [ViewController:: class, 'branch_inventory']);


//Login
Route::post('login', [LoginController:: class, 'valid']);
Route::get('/logout', [LoginController:: class, 'logout']);

//Request Form
Route::post('newRequest', [RequestController:: class, 'store']);

//Display for branch inventory
Route::get('/showInv', [BranchInventory:: class, 'show']);
Route::get('/searchItem', [BranchInventory:: class, 'action'])->name('branch_inventory.action');

// Products Page Actions
Route::get('/products', [ViewController:: class, 'products_page']);
Route::get('/addItem', [ProductsPage:: class, 'store']);
Route::get('/displayItems', [ProductsPage:: class, 'show']);
Route::delete('cancelItem', [ProductsPage:: class, 'destroy']);
Route::get('/searchProduct', [ProductsPage:: class, 'action'])->name('products_page.action');