<?php $__env->startSection('products'); ?>
    bg-gray-500
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="flex justify-center">
     
    <div class="w-1/4  p-8 mt-48 bg-white bg-opacity-70 rounded-md">
       
        <div class = "mb-12">
            <h2 class="text-center text-2xl ">Create Request</h2>
        </div>
        <form action="<?php echo e(route('newRequest')); ?>" method = "POST">
            <?php echo csrf_field(); ?>
            <div class = "mb-4">
                <label for="paymentType" class="ml-6 ">Payment Type:</label>
                <select name="paymentType" id="ptype" class="mb-8">
                    <option value="Cash">Cash</option>
                    <option value="Credit">Credit</option>  
                </select> 
            </div>
            
            <div class="flex justify-center mt-4">
                <button type="submit" name="createRequest" class="bg-blue-500 text-white px-4 py-3 rounded-sm font-medium w-1/2 hover:bg-blue-300 ">Create Request</button>
            </div>  
        
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jack\Downloads\JED edits\Saribase-front-end\resources\views/contents/requestForm.blade.php ENDPATH**/ ?>