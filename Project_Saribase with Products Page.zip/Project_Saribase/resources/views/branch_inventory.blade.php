@extends('layout')

@section('forms')
    <div align= "center"id= "loginform" class = "jumbotron" >
            <h1>This is the Branch Inventory Page</h1>
            <center>Item to Search:<input type="text" id="search" name ="search" placeholder = "Item to request"></center>
            <center>
                <table>
                    <thead>
                    <tr>
                    <th> Item ID </th>
                    <th> Item Name </th>
                    <th> Branch ID </th>
                    <th> Item Quantity </th>
                    </tr>
                    </thead>
                    <tbody class= 'filter' >

                    </tbody>
            </table></center><br>

            <table>
                <thead>
                     <tr>
                        <th> Branch ID </th>
                        <th> Item ID </th>
                        <th> Item Name </th>
                        <th> TagListID </th>
                        <th> Main </th>
                        <th> Branch A </th>
                        <th> Branch B </th>
                    </tr>
                </thead>
                <tbody>
                @foreach($getInv as $b)
                    <tr>
                        <td>{{$b->branchID}}</td>
                        <td>{{$b->itemID}}</td>
                        <td>{{$b->itemName}}</td>
                        <td>{{$b->tagListID}}</td>

                        @if($b->branchID == 1)
                        <center><td>{{$b->itemQuantity}}</td></center> 
                        <center><td> 0 </td></center> 
                        <center><td> 0 </td></center> 
                        @elseif($b->branchID == 2)
                        <center><td> 0 </td></center> 
                        <center><td>{{$b->itemQuantity}}</td></center> 
                        <center><td> 0 </td></center> 
                        @elseif($b->branchID == 3)
                        <center><td> 0 </td></center> 
                        <center><td> 0 </td></center> 
                        <center><td>{{$b->itemQuantity}}</td></center> 
                        @else
                        <center><td> 0 </td></center> 
                        <center><td> 0 </td></center> 
                        <center><td> 0 </td></center> 
                        @endif

                        <td>
                        <form action="" method= "POST">
                            @csrf
                            @method('delete')
                            <input type="hidden" name="id" value = {{$b->itemID}}>
                            <button  class= "btn btn-primary">Cancel</button>
                        </form>
                        </td>
                    </tr> 
               
                    @endforeach
                </tbody>
            </table>
     
            <button onclick="window.location='{{ url('/request') }}'"  class= "btn btn-primary"> Return to Request page "temp admin page" </button>
        </div>
       
        <script type="text/javascript">
        $('#search').on('keyup',function(){
            $value=$(this).val();
                $.ajax({
                type : 'get',
                url : '{{URL::to('searchItem')}}',
                data:{'search':$value},
                success:function(data){
                $('tbody.filter').html(data);
                }
            });
        })

    </script>
        <script type="text/javascript">
            $.ajaxSetup({ headers: { 'csrftoken' : '{{ csrf_token() }}' } });
        </script>

@endsection

