@extends('layout')

@section('forms')

<center><h1> Request PAGE</h1></center>
<div align= "center" id= "loginform" class = "jumbotron" >
        <h2>Create a request</h2>
        <form action="newRequest" method = "POST">
            @csrf
           <center>Payment Type:
            <select name="paymentType" id="ptype">
            <option value="Cash">Cash</option>
            <option value="Credit">Credit</option>
            </select></center><br>
            <center><button name="createRequest" class= "btn btn-primary">Create Request </button></center>

        </form>
        
        <button onclick="window.location='{{ url('/logout') }}'" class= "btn btn-primary"> Logout</button>
        /*Added this for the branch inventory display */
        <button onclick="window.location='{{ url('/showInv') }}'" class= "btn btn-primary"> Show Branch Inventory</button>

    </div>

@endsection
   