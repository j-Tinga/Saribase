@extends('layout.layout')

@section('dashboard')
    bg-gray-500
@endsection

@section('content')


<div class="flex justify-center">
       
    THIS IS THE DASHBOARD

</div>


   
@endsection