

<?php $__env->startSection('forms'); ?>
    <center><h1> LOGIN PAGE</h1></center>

    <div align= "center" id= "loginform" class = "jumbotron" >

        <form action="login" method = "POST">
        <?php echo csrf_field(); ?>
        <center><input type="text" name = "empID"  placeholder = "Employee ID"></center>
        <center><input type="password" name = "password" placeholder = "Password" ></center>
        <center><button class= "btn btn-primary" name = "login" >Login</button></center>

        </form>
        
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jack\Desktop\Laravel\Project_Saribase\resources\views/login.blade.php ENDPATH**/ ?>