<?php $__env->startSection('branches'); ?>
    bg-gray-500
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="grid grid-cols-3 gap-4 p-8 justify-center">
                    
                    
                         
    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                
                <div class=" m-8 text-center">
                    
                        <h1 class=" mb-10 text-xl font-bold "> <?php echo e($branch->branchName); ?> </h1>
                        <h1 class="mb-2 text-l font-bold"><?php echo e($branch->branchAddress); ?> </h1>
                        <h1 class=" mb-2 text-l font-bold"> <?php echo e($branch->branchContact); ?> </h1>   
                </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jack\Downloads\JED edits\Saribase-front-end\resources\views/contents/branches.blade.php ENDPATH**/ ?>