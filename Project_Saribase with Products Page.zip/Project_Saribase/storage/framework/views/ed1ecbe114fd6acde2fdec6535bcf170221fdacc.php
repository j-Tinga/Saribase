

<?php $__env->startSection('forms'); ?>
<center><h1> PRODUCTS PAGE</h1></center>
<div class = "jumbotron" >
    
            <center>Product to Search:<input type="text" id="search" name ="search" placeholder = "Item to request"></center>
            <center>
                <h3>Total Record: <span id ='#total_data'></span></h3>
                <table>
                    <thead>
                    <tr>
                    <th> Item ID </th>
                    <th> Item Name </th>
                    <th> TagListID </th>
                    <th> TagID </th>
                    <th> TagName </th>
                    <th> Stock </th>
                    <th> Action </th>
                    </tr>
                    </thead>
                    <tbody>
                    
                    </tbody>
                </table></center><br>
                
            <?php if(Session::get('requestID') == null): ?>
            <button onclick="window.location='<?php echo e(url('/request')); ?>'" class= "btn btn-primary"> Request Form </button>
            <?php endif; ?>

            <button onclick="window.location='<?php echo e(url('/displayItems')); ?>'" class= "btn btn-primary"> View Request List </button>
    </div>

    <!-- Live search ajax  -->
    <script type="text/javascript">
        $('#search').on('keyup',function(){
            $value=$(this).val();
                $.ajax({
                type : 'get',
                url : '<?php echo e(URL::to('searchProduct')); ?>',
                data:{'search':$value},
                success:function(data){
                $('tbody').html(data);
                }
            });
        })

    </script>
        <script type="text/javascript">
            $.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
        </script>

<?php $__env->stopSection(); ?>

<style scoped>
.jumbotron{
    width: 1000px;
}
</style>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jack\Desktop\Laravel\Project_Saribase\resources\views/products_page.blade.php ENDPATH**/ ?>