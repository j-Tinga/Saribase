<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class ViewController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function home()
    {
        return view('home');
    }
    public function loginform()
    {
        return view('login');
    }
    public function requestform()
    {
        return view('request');
    }
    public function request_list()
    {
        return view('request_list');
    }

    public function branch_inventory()
    {
        return view('branch_inventory');
    }
    // newly added 
    public function products_page()
    {
        return view('products_page');
    }



}
