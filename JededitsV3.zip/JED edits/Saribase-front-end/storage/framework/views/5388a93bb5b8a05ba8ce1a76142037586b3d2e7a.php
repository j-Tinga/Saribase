<?php $__env->startSection('dashboard'); ?>
    bg-gray-500
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="flex justify-center">
       
    THIS IS THE DASHBOARD

</div>


   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jack\Downloads\JED edits\Saribase-front-end\resources\views/contents/dashboard.blade.php ENDPATH**/ ?>