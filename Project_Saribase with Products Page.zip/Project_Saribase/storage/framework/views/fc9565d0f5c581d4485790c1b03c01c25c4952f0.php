

<?php $__env->startSection('forms'); ?>
    <div align= "center"id= "loginform" class = "jumbotron" >
            <h1>This is the Request List</h1>
            <table>
                <thead>
                     <tr>
                        <th> Item ID </th>
                        <th> Item Name </th>
                        <th> Quantity </th>
                        <th> Action </th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $reqList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($b->requestID == Session::get('requestID')): ?>
                    <tr>
                        <td><?php echo e($b->itemID); ?></td>
                        <td><?php echo e($b->itemName); ?></td>
                        <center><td><?php echo e($b->quantityRequested); ?></td></center>
                        <td>
                        <form action="cancelItem" method= "POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <input type="hidden" name="itemID" value = <?php echo e($b->itemID); ?>>
                            <button  class= "btn btn-primary">Cancel</button>
                        </form>
                        </td>
                    </tr> 
                    <?php endif; ?>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
     
            <button onclick="window.location='<?php echo e(url('/products')); ?>'"  class= "btn btn-primary"> Return to Products page </button>
        </div>
       
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jack\Desktop\Laravel\Project_Saribase\resources\views/displayList.blade.php ENDPATH**/ ?>