@extends('layout')

@section('forms')
    <center><h1> LOGIN PAGE</h1></center>

    <div align= "center" id= "loginform" class = "jumbotron" >

        <form action="login" method = "POST">
        @csrf
        <center><input type="text" name = "empID"  placeholder = "Employee ID"></center>
        <center><input type="password" name = "password" placeholder = "Password" ></center>
        <center><button class= "btn btn-primary" name = "login" >Login</button></center>

        </form>
        
        </div>
@endsection