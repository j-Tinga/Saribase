<?php $__env->startSection('content'); ?>


<div class="flex justify-center">
       
    <div class="w-1/4  p-10 mt-48 bg-white bg-opacity-70 rounded-md">
       
        <form action="<?php echo e(route('login')); ?>" method = "post">
            <?php echo csrf_field(); ?>
            <div class = "mb-16">
                <h2 class="text-center text-4xl ">Log In</h2>
            </div>
            
            <div class = "mb-4">
                <label for="empID" class ="sr-only">Employee ID</label>
                <input type="text" name = "empID"  placeholder = "Employee ID" class="bg-gray-200 border-2 w-full h-1/3 p-4 rounded-sm ">
               
            </div>
            <div class = "mb-4">
                <label for="password" class ="sr-only">Password</label>
                <input type="password"name="password" id="password" placeholder="Password" class="bg-gray-200 border-2 w-full h-1/3 p-4 rounded-sm <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <?php if($message = Session::get('status')): ?>
            <div class ="text-center text-red-500 mt-4">
                <?php echo e($message); ?> 
            </div>
            <?php endif; ?>

            <div class="flex justify-center mt-4">
                <button type="submit" class="bg-blue-500 text-white px-4 py-3 rounded-sm font-medium w-1/2 hover:bg-blue-300 ">Login</button>
            </div>  
            
        </form>
    </div>
</div>


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jack\Downloads\Saribase- with admin\Saribase-front-end\resources\views/contents/login.blade.php ENDPATH**/ ?>