<?php 
               $item = $_GET['name'];

               $data = $conn->query("SELECT itemName,itemID FROM item WHERE itemName LIKE '%$item%' LIMIT 2"); // limit to how many results to be shown at default//
                
               while($row = $data->fetch_assoc()){
        
                   echo   "<tbody><tr>
                            <td><center> ".$row['itemName']." </center></td>";
           
                     echo '<center><form action="addToList" method = "POST">
                            <td> Quantity:<input type="number" name = "quantity" min="1" max="50">
                            <td><input type="hidden" name= "itemID" value = "'.$row["itemID"].'">
                            <input type = "submit" name ="addItem" class= "btn btn-warning" value = ADD>
                            </td></form></center>
                            </tr>';
           
               }
//LIVE SEARCH BUT IDK WHY IT WONT WORK
//    <script type = "text/javascript">
//     $(document).ready(function(){

//         fetch_item_data();
//         function fetch_item_data(query = '')
//         {
//             $.ajax({
//                 url: '{{route('request_list.action')}}',
//                 method: 'GET',
//                 data:{'query':query},
//                 dataType: 'json',
//                 success:function(data){
//                     $('tbody').html(data.table_data);
//                     $('#total_data').text(data.total_data);
//                 }
//             })
//         }

//         $(document).on('keyup', '#search', function(){
//             var query = $(this).val();
//             fetch_item_data(query);

//         });
//     });

//     </script> 

// The Controller function 
// public function action (Request $request){
       // if($request->ajax())
       // {
       //     $query = $request->get('query');
       //     if($query != '')
       //     {
       //         $data = DB::table('item')->where('itemName', 'like', '%' .$query. '%')->get();
       //         // ->select('itemID', 'itemName')
       //     }
       //     else
       //     {
       //         $data = DB::table('item')->orderBy('itemID', 'desc')->get();
       //     }

       //     $total_row = $data->count();
       //     if($total_row > 0)
       //     {
       //         foreach($data as $row)
       //         {
       //             $output .='
       //             <tr> 
       //                 <td>'.$row->itemName.'</td>
       //                 <td>'.$row->itemID.'</td>
       //             </tr>';
       //         }
       //     }
       //     else
       //     {
       //         $output = '
       //             <tr> 
       //                 <td align = center >
       //                     No Data Found
       //                 </td>
       //             </tr>
       //         ';
       //     }

       //     $data = array(
       //         'table_data' => $output,
       //         '$total_data' => $total_data

       //     );

       //     echo json_encode($data);
       // };
// }
 // 
    ?>

    <!-- tried to not place it on the same row -->
<!-- <form action="/addItem" method = "GET">
                <table>
                    <thead>
                    <tr>
                    <th>cb</th>
                    <th> Item ID </th>
                    <th> Item Name </th>
                    <th> Tags </th>
                    <th> Stock </th>
                    <th> Action </th>
                    </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table></center><br>
                @if(Input::get('itemID') == checked)
                Quantity <input type = "number" name = "quantity" class="number" min= 0 max= 50>
                <button class= "btn btn-primary"> Request Item </button>
                @endif
                </form> -->

                @foreach($items as $key => $item)
                        <tr>    
                            <td>{{$item->itemID}}</td>
                            <td>{{$item->itemName}}</td>
                            <td>{{$item->tagListID}}</td>
            
                            <td>{{$item->itemQuantity}}</td>
                            <form action="/addItem" method = "GET">
                                    <input type="checkbox" name = "itemID" value= {{$item->itemID}}>
                                    Quantity <input type = "number" name = "quantity" class="number" min= 0 max= 50>
                                    <button class= "btn btn-primary Add" > Add </button>
                            </form></td>
                        </tr>
                        @endforeach