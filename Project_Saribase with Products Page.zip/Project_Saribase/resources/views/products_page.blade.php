@extends('layout')

@section('forms')
<center><h1> PRODUCTS PAGE</h1></center>
<div class = "jumbotron" >
    
            <center>Product to Search:<input type="text" id="search" name ="search" placeholder = "Item to request"></center>
            <center>
                <h3>Total Record: <span id ='#total_data'></span></h3>
                <table>
                    <thead>
                    <tr>
                    <th> Item ID </th>
                    <th> Item Name </th>
                    <th> TagListID </th>
                    <th> TagID </th>
                    <th> TagName </th>
                    <th> Stock </th>
                    <th> Action </th>
                    </tr>
                    </thead>
                    <tbody>
                    
                    </tbody>
                </table></center><br>
                
            @if (Session::get('requestID') == null)
            <button onclick="window.location='{{ url('/request') }}'" class= "btn btn-primary"> Request Form </button>
            @endif

            <button onclick="window.location='{{ url('/displayItems') }}'" class= "btn btn-primary"> View Request List </button>
    </div>

    <!-- Live search ajax  -->
    <script type="text/javascript">
        $('#search').on('keyup',function(){
            $value=$(this).val();
                $.ajax({
                type : 'get',
                url : '{{URL::to('searchProduct')}}',
                data:{'search':$value},
                success:function(data){
                $('tbody').html(data);
                }
            });
        })

    </script>
        <script type="text/javascript">
            $.ajaxSetup({ headers: { 'csrftoken' : '{{ csrf_token() }}' } });
        </script>

@endsection

<style scoped>
.jumbotron{
    width: 1000px;
}
</style>