<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Session;
use Illuminate\Http\Request;

class ViewController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function dashboard()
    {
        return view('contents.dashboard');
    }
    public function loginform()
    {
        return view('contents.login');
    }
    public function requests(Request $request)
    {
        $requests = DB::table('request')
        ->join('employee', 'request.requesterID', 'employee.employeeID')
        ->join('branch', 'employee.branchID', 'branch.branchID')->get();

        $id = $request->session()->get('reqID');

        $getList = DB::table('request_list')
        ->join('item', 'request_list.itemID','item.itemID')
        ->where('request_list.requestID', $id)->get();
      
        return view('contents.requests')->with('requests', $requests)->with('reqList', $getList);  
        // $request->session()->forget('reqID');
    }
    public function products()
    {
        $items = DB::table('item')
                ->join('branch_inventory', 'item.itemID','branch_inventory.itemID')
                ->join('tag_list', 'item.itemID','tag_list.itemID')
                ->join('tag', 'tag_list.tagID', 'tag.tagID')
                ->where('branchID',Session::get('branchID'))
                ->orderBy('itemQuantity', 'asc')->get();

        $getList = DB::table('request_list')
                ->join('item', 'request_list.itemID', '=', 'item.itemID')
                ->select('request_list.*', 'item.itemName')
                ->where('request_list.requestID', Session::get('requestID'))->get();

        return view('contents.products')->with('items', $items)->with('reqList', $getList);
    }
    
    public function branches()
    {
        $branches = DB::table('branch')->get();
       
        return view('contents.branches',[
            'branches'=>$branches,
        ]);
    }
    public function admin(){
        $branchID = DB::table('branch')->get('branchID');
        
        return view('contents.admin', ['branches'=>$branchID]);
    }
    public function requestForm()
    {
        return view('contents.requestForm');
    }
}
